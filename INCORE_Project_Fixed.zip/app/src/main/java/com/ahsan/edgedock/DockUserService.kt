package com.ahsan.edgedock

import android.content.Context
import android.content.ContextWrapper
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import java.lang.reflect.Method
import kotlin.system.exitProcess

/**
 * Runs in a separate process with shell (adb) privileges, started by Shizuku.
 * Creates a full-size virtual display, so the app lays out like on a normal full screen;
 * DockService then shows that display scaled-down inside a small overlay window.
 */
class DockUserService : IDockService.Stub() {
    private val displays = HashMap<Int, VirtualDisplay>()
    private var dm: DisplayManager? = null
    private var err = ""
    private val thread = HandlerThread("dock-vd").also { it.start() }
    private val handler = Handler(thread.looper)

    private var inputMgr: Any? = null
    private var injectM: Method? = null
    private var setDisplayM: Method? = null

    private fun displayManager(): DisplayManager {
        dm?.let { return it }
        val atClass = Class.forName("android.app.ActivityThread")
        val ctor = atClass.getDeclaredConstructor().apply { isAccessible = true }
        val at = ctor.newInstance()
        atClass.getDeclaredField("sCurrentActivityThread").apply { isAccessible = true }.set(null, at)
        atClass.getDeclaredField("mSystemThread").apply { isAccessible = true }.setBoolean(at, true)
        val sys = atClass.getDeclaredMethod("getSystemContext").invoke(at) as Context
        val fake = object : ContextWrapper(sys) {
            fun getOpPackageName(): String = "com.android.shell"
            override fun getPackageName(): String = "com.android.shell"
            override fun getApplicationContext(): Context = this
        }
        val c = DisplayManager::class.java.getDeclaredConstructor(Context::class.java).apply { isAccessible = true }
        return c.newInstance(fake).also { dm = it }
    }

    override fun createDisplay(surface: Surface, width: Int, height: Int, dpi: Int): Int {
        return try {
            val base = 1 or 2 or 8 or (1 shl 6) or (1 shl 7) or (1 shl 8) // PUBLIC|PRESENTATION|OWN_CONTENT_ONLY|SUPPORTS_TOUCH|ROTATES_WITH_CONTENT|DESTROY_CONTENT_ON_REMOVAL
            val extra = if (Build.VERSION.SDK_INT >= 33) (1 shl 10) or (1 shl 11) or (1 shl 12) or (1 shl 13) else 0 // TRUSTED|OWN_DISPLAY_GROUP|ALWAYS_UNLOCKED|TOUCH_FEEDBACK_DISABLED
            val mgr = displayManager()
            val vd = try {
                mgr.createVirtualDisplay("EdgeDock", width, height, dpi, surface, base or extra, null, handler)
            } catch (e: Throwable) {
                mgr.createVirtualDisplay("EdgeDock", width, height, dpi, surface, base, null, handler)
            }
            val id = vd.display.displayId
            displays[id] = vd
            id
        } catch (e: Throwable) {
            err = "VD: " + (e.cause ?: e).toString(); -1
        }
    }

    override fun launch(displayId: Int, component: String) {
        try {
            Runtime.getRuntime().exec(arrayOf("sh", "-c", "am start --display $displayId -n $component")).waitFor()
        } catch (e: Throwable) { err = "launch: $e" }
    }

    private fun ensureInput() {
        if (injectM != null) return
        val im = Class.forName("android.hardware.input.InputManager")
        inputMgr = im.getDeclaredMethod("getInstance").apply { isAccessible = true }.invoke(null)
        injectM = im.getDeclaredMethod("injectInputEvent", android.view.InputEvent::class.java, Int::class.javaPrimitiveType)
            .apply { isAccessible = true }
        setDisplayM = android.view.InputEvent::class.java.getDeclaredMethod("setDisplayId", Int::class.javaPrimitiveType)
            .apply { isAccessible = true }
    }

    override fun inject(displayId: Int, action: Int, x: Float, y: Float, downTime: Long) {
        try {
            ensureInput()
            val e = MotionEvent.obtain(downTime, SystemClock.uptimeMillis(), action, x, y, 0)
            e.setSource(InputDevice.SOURCE_TOUCHSCREEN)
            setDisplayM!!.invoke(e, displayId)
            injectM!!.invoke(inputMgr, e, 0)
            e.recycle()
        } catch (t: Throwable) { err = "inject: " + (t.cause ?: t) }
    }

    override fun key(displayId: Int, keyCode: Int) {
        try {
            ensureInput()
            for (down in booleanArrayOf(true, false)) {
                val now = SystemClock.uptimeMillis()
                val k = KeyEvent(now, now, if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, keyCode, 0)
                k.setSource(InputDevice.SOURCE_KEYBOARD)
                setDisplayM!!.invoke(k, displayId)
                injectM!!.invoke(inputMgr, k, 0)
            }
        } catch (t: Throwable) { err = "key: " + (t.cause ?: t) }
    }

    override fun release(displayId: Int) {
        try { displays.remove(displayId)?.release() } catch (ignored: Throwable) {}
    }

    override fun lastError(): String = err

    override fun destroy() {
        displays.values.forEach { try { it.release() } catch (ignored: Throwable) {} }
        displays.clear()
        exitProcess(0)
    }
}
