# INCORE (EdgeDock) 1.4

Lavender edge-line dock. Tap or swipe-left on the line -> app icons -> tap an icon -> the app opens zoomed-out (whole screen, scaled down).
Window top bar: drag = move, tap = full screen <-> small, drag into right edge = close, ‹ = back.
Panel: ✕ at the top closes all open windows. The notification has a Stop button.
Needs: Overlay permission + Shizuku running.
If the zoom-out (virtual display) mode fails on a device, it falls back to freeform small windows and shows the error in a toast.

## Build on GitHub
1. Upload the CONTENTS of this folder to the repository root (not the zip itself). The hidden `.github` folder must be included.
   If the browser skips it: Add file -> Create new file -> name `.github/workflows/build.yml` and paste the contents of `GITHUB_WORKFLOW_COPY.yml` from this project.
2. Open the Actions tab -> "Build INCORE APK" -> Run workflow (it also runs on every push).
3. When it is green, open the run -> Artifacts -> `INCORE-debug-apk`.
