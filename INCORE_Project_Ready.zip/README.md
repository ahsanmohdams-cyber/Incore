# EdgeDock 1.2
Lavender edge-line dock. Tap or swipe-left on the line -> app icons -> tap an icon -> the app opens zoomed-out (whole screen, scaled down).
Window top bar: drag = move, tap = full screen <-> small, drag into right edge = close, ‹ = back.
Panel: ✕ at the top closes all open windows. The notification has a Stop button.
Needs: Overlay permission + Shizuku running. Push to GitHub (main) -> Actions builds the APK (Artifacts).
If the zoom-out (virtual display) mode fails on a device, it falls back to the old freeform small windows and shows the error in a toast.
