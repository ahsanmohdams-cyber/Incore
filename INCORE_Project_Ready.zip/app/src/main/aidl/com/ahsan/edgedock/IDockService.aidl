package com.ahsan.edgedock;

import android.view.Surface;

interface IDockService {
    void destroy() = 16777114;
    /** Creates a full-screen-sized virtual display that draws into [surface]. Returns display id or -1 (see lastError). */
    int createDisplay(in Surface surface, int width, int height, int dpi) = 1;
    void launch(int displayId, String component) = 2;
    oneway void inject(int displayId, int action, float x, float y, long downTime) = 3;
    void key(int displayId, int keyCode) = 4;
    void release(int displayId) = 5;
    String lastError() = 6;
}
