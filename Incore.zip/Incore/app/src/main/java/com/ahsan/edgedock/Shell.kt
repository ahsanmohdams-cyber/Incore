package com.ahsan.edgedock

import rikka.shizuku.Shizuku

/** Runs shell commands with Shizuku's privileges (adb-level). */
object Shell {
    fun ready() = try { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == 0 } catch (e: Throwable) { false }

    fun run(cmd: String): String = try {
        val m = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor(); out
    } catch (e: Throwable) { "" }

    /** Open app in freeform mode, return its task id (or -1). */
    fun launchFreeform(pkg: String, l: Int, t: Int, r: Int, b: Int): Int {
        run("settings put global enable_freeform_support 1; settings put global force_resizable_activities 1")
        val comp = run("cmd package resolve-activity --brief -c android.intent.category.LAUNCHER $pkg").lines().lastOrNull { it.contains("/") }?.trim() ?: return -1
        run("am start -n $comp --windowingMode 5")
        Thread.sleep(700)
        val id = taskId(pkg)
        if (id > 0) resize(id, l, t, r, b)
        return id
    }

    fun taskId(pkg: String): Int {
        val d = run("dumpsys activity activities")
        val re = Regex("Task\\{[^}]*#(\\d+)[^}]*A=\\d+:" + Regex.escape(pkg))
        return re.findAll(d).lastOrNull()?.groupValues?.get(1)?.toIntOrNull() ?: -1
    }

    fun resize(id: Int, l: Int, t: Int, r: Int, b: Int) { run("am task resize $id $l $t $r $b") }
    fun close(pkg: String) { run("am force-stop $pkg") }
}
