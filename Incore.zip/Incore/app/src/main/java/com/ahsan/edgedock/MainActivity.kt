package com.ahsan.edgedock

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#F5F0FF")); setPadding(48, 48, 48, 48)
        }
        setContentView(root)
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#9B7FD4")); setOnClickListener { f() }
        }.also { root.addView(it, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 16, 0, 16) }) }
        btn("1. Overlay permission") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        btn("2. Shizuku permission") {
            try { Shizuku.requestPermission(1) } catch (e: Throwable) { Toast.makeText(this, "Shizuku app തുറന്ന് start ചെയ്യൂ", Toast.LENGTH_LONG).show() }
        }
        btn("3. Start dock") {
            if (!Settings.canDrawOverlays(this)) Toast.makeText(this, "Overlay permission വേണം", Toast.LENGTH_SHORT).show()
            else startForegroundService(Intent(this, DockService::class.java))
        }
        btn("Stop dock") { stopService(Intent(this, DockService::class.java)) }
    }
}
