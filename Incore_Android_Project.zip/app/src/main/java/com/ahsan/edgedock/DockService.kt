package com.ahsan.edgedock

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.*
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.SystemClock
import android.view.*
import android.view.animation.PathInterpolator
import android.widget.*
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.min

/**
 * Edge dock v1.1
 *  - wide invisible touch area around the slim lavender line (swipe left or tap to open)
 *  - icon panel is pre-built in the background, opens/closes with smooth animations (no lag)
 *  - apps open on a full-size virtual display and are shown scaled-down (zoomed out, whole screen visible)
 *  - if the virtual display can't be created, falls back to the old freeform small windows
 */
@SuppressLint("ClickableViewAccessibility")
class DockService : Service() {
    private val MAX = 6
    companion object { const val ACTION_STOP = "com.ahsan.edgedock.STOP" }
    private lateinit var wm: WindowManager
    private var handle: View? = null
    private var panel: ScrollView? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var panelOpen = false
    private lateinit var col: LinearLayout
    private val ui by lazy { Handler(mainLooper) }
    private val LAV = Color.parseColor("#B8A1E8")
    private val LAV_BG = Color.parseColor("#F5F0FF")
    private val EASE_OUT = PathInterpolator(0.2f, 0f, 0f, 1f)
    private val EASE_IN = PathInterpolator(0.4f, 0f, 1f, 1f)

    // pkg -> slot, for every app that is open or opening
    private val slotOf = LinkedHashMap<String, Int>()

    // ---------- legacy (freeform) windows ----------
    private class Win(val pkg: String, val slot: Int, val id: Int, var l: Int, var t: Int, val w: Int, val h: Int, val grip: View) {
        var full = false
    }
    private val wins = LinkedHashMap<String, Win>()

    // ---------- virtual display windows ----------
    private class VWin(val pkg: String, val slot: Int) {
        lateinit var root: FrameLayout
        lateinit var lp: WindowManager.LayoutParams
        var surface: Surface? = null
        @Volatile var displayId = -1
        var full = false
        var sx = 0; var sy = 0; var sw = 0; var sh = 0
        var downTime = 0L
        var closing = false
    }
    private val vwins = LinkedHashMap<String, VWin>()

    // ---------- Shizuku user service ----------
    @Volatile private var svc: IDockService? = null
    private var binding = false
    private val userArgs by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, DockUserService::class.java.name))
            .daemon(false).processNameSuffix("dockvd").version(1)
    }
    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            svc = if (b != null && b.pingBinder()) IDockService.Stub.asInterface(b) else null
        }
        override fun onServiceDisconnected(n: ComponentName?) { svc = null; binding = false }
    }
    private fun bindSvc() {
        if (svc != null || binding || !Shell.ready()) return
        try { binding = true; Shizuku.bindUserService(userArgs, conn) } catch (e: Throwable) { binding = false }
    }
    private fun awaitService(): IDockService? {
        bindSvc()
        repeat(40) {
            svc?.let { s -> if (s.asBinder().isBinderAlive) return s }
            Thread.sleep(100)
        }
        return null
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onBind(i: Intent?): IBinder? = null

    private val pkgRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { buildApps() }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("dock", "Dock", NotificationManager.IMPORTANCE_MIN))
        startForeground(1, buildNotification())
        showHandle()
        createPanel()      // built once, hidden
        buildApps()        // icons loaded on a background thread
        val pkgFilter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(pkgRx, pkgFilter, Context.RECEIVER_EXPORTED)
        else registerReceiver(pkgRx, pkgFilter)
        bindSvc()          // warm up the virtual-display helper so the first open is fast
    }

    private fun buildNotification(): Notification {
        val stop = PendingIntent.getService(
            this, 0, Intent(this, DockService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop
        ).build()
        return Notification.Builder(this, "dock")
            .setSmallIcon(android.R.drawable.ic_menu_more)
            .setContentTitle("Incore")
            .setOngoing(true)
            .addAction(action)
            .build()
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        return START_STICKY
    }

    private fun lp(w: Int, h: Int, gravity: Int, x: Int = 0, y: Int = 0) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED, PixelFormat.TRANSLUCENT
    ).also { it.gravity = gravity; it.x = x; it.y = y }

    private fun toast(m: String) = ui.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }

    // =====================================================================
    //  Edge handle: slim line, but a 32dp x 180dp touch area around it
    // =====================================================================
    private fun showHandle() {
        val pill = View(this).apply {
            background = GradientDrawable().apply { setColor(LAV); cornerRadius = dp(4).toFloat(); setStroke(dp(1), Color.WHITE) }
            pivotX = dp(8).toFloat()
        }
        val box = FrameLayout(this)
        box.addView(pill, FrameLayout.LayoutParams(dp(8), dp(110), Gravity.END or Gravity.CENTER_VERTICAL))
        if (Build.VERSION.SDK_INT >= 29) {
            // stop the system back-gesture from stealing touches on the edge
            box.addOnLayoutChangeListener { v, l, t, r, b, _, _, _, _ -> v.systemGestureExclusionRects = listOf(Rect(0, 0, r - l, b - t)) }
        }
        var downX = 0f; var dx = 0f
        box.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; dx = 0f
                    pill.animate().scaleX(1.8f).scaleY(1.08f).setDuration(120).start()
                    box.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                }
                MotionEvent.ACTION_MOVE -> dx = e.rawX - downX
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    pill.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
                    if (e.actionMasked == MotionEvent.ACTION_UP) {
                        when {
                            dx < -dp(14) -> openPanel()      // swipe left
                            dx > dp(14) -> closePanel()      // swipe right
                            else -> togglePanel()            // tap
                        }
                    }
                }
            }
            true
        }
        handle = box
        wm.addView(box, lp(dp(32), dp(180), Gravity.END or Gravity.CENTER_VERTICAL))
    }

    // =====================================================================
    //  Icon panel: created once, filled in the background, animated in/out
    // =====================================================================
    private fun createPanel() {
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val sv = ScrollView(this).apply {
            addView(col)
            isVerticalScrollBarEnabled = false
            background = GradientDrawable().apply { setColor(LAV_BG); cornerRadius = dp(18).toFloat(); setStroke(dp(2), LAV) }
            visibility = View.INVISIBLE
            alpha = 0f
        }
        val p = lp(dp(66), (resources.displayMetrics.heightPixels * 0.7).toInt(), Gravity.END or Gravity.CENTER_VERTICAL, dp(10))
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        panel = sv; panelLp = p
        wm.addView(sv, p)
    }

    private fun buildApps() {
        thread {
            val pm = packageManager
            val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .map { it.activityInfo.packageName to it.loadIcon(pm) }
            ui.post {
                col.removeAllViews()
                col.addView(closeAllView(), LinearLayout.LayoutParams(dp(46), dp(34)).apply { setMargins(0, dp(2), 0, dp(4)) })
                list.forEach { (pkg, icon) -> col.addView(iconView(pkg, icon), LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(0, dp(6), 0, dp(6)) }) }
            }
        }
    }

    private fun closeAllView() = TextView(this).apply {
        text = "✕"; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER
        background = GradientDrawable().apply { setColor(LAV); cornerRadius = dp(12).toFloat() }
        setOnClickListener { closeAll(); closePanel() }
    }

    private fun iconView(pkg: String, icon: Drawable) = ImageView(this).apply {
        setImageDrawable(icon)
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
        setOnClickListener { closePanel(); openWindow(pkg) }
    }

    private fun togglePanel() { if (panelOpen) closePanel() else openPanel() }

    private fun setPanelTouchable(on: Boolean) {
        val v = panel ?: return; val p = panelLp ?: return
        p.flags = if (on) p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv() else p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm.updateViewLayout(v, p) } catch (ignored: Throwable) {}
    }

    private fun openPanel() {
        val v = panel ?: return
        if (panelOpen) return
        panelOpen = true
        setPanelTouchable(true)
        v.animate().cancel()
        v.visibility = View.VISIBLE
        v.translationX = dp(70).toFloat(); v.alpha = 0f
        v.animate().translationX(0f).alpha(1f).setDuration(280).setInterpolator(EASE_OUT).withLayer().start()
    }

    private fun closePanel() {
        val v = panel ?: return
        if (!panelOpen) return
        panelOpen = false
        v.animate().cancel()
        v.animate().translationX(dp(70).toFloat()).alpha(0f).setDuration(200).setInterpolator(EASE_IN).withLayer().withEndAction {
            if (!panelOpen) { v.visibility = View.INVISIBLE; setPanelTouchable(false) }
        }.start()
    }

    // =====================================================================
    //  Opening apps
    // =====================================================================
    private fun freeSlot() = (0 until MAX).first { s -> !slotOf.containsValue(s) }

    private fun openWindow(pkg: String) {
        if (!Shell.ready()) { toast("Shizuku permission വേണം"); return }
        if (slotOf.containsKey(pkg)) { toast("ഇത് ഇപ്പോൾ തന്നെ തുറന്നിട്ടുണ്ട്"); return }
        if (slotOf.size >= MAX) { toast("പരമാവധി $MAX ആപ്പ്"); return }
        val slot = freeSlot()
        slotOf[pkg] = slot                      // reserve immediately
        val comp = packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToShortString()
        if (comp == null) { slotOf.remove(pkg); toast("ഈ ആപ്പ് തുറക്കാൻ പറ്റുന്നില്ല"); return }
        thread {
            val s = awaitService()
            if (s != null) ui.post { addVirtual(pkg, slot, comp) } else ui.post { legacyOpen(pkg, slot) }
        }
    }

    // ---------- zoomed-out windows on a full-size virtual display ----------
    private fun smallRect(slot: Int): IntArray {
        val dm = resources.displayMetrics; val W = dm.widthPixels; val H = dm.heightPixels
        val m = dp(6); val top = dp(30); val bottom = dp(16)
        val s = min((W - m * 3) / 2f / W, (H - top - bottom - m * 3) / 2f / H)
        val w = (W * s).toInt(); val h = (H * s).toInt()
        val casc = (slot / 4) * dp(28)
        return intArrayOf(m + (slot % 2) * (w + m) + casc, top + ((slot / 2) % 2) * (h + m) + casc, w, h)
    }

    private fun addVirtual(pkg: String, slot: Int, comp: String) {
        val dm = resources.displayMetrics; val W = dm.widthPixels; val H = dm.heightPixels
        val (x, y, w, h) = smallRect(slot)
        val vw = VWin(pkg, slot).also { it.sx = x; it.sy = y; it.sw = w; it.sh = h }

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(14).toFloat()) }
            }
        }
        val tv = TextureView(this)
        root.addView(tv, FrameLayout.LayoutParams(-1, -1))

        // top bar: drag = move, tap = full screen <-> small, drag to the right edge = close
        val bar = FrameLayout(this)
        val pill = View(this).apply { background = GradientDrawable().apply { setColor(LAV); cornerRadius = dp(3).toFloat(); setStroke(dp(1), Color.WHITE) } }
        bar.addView(pill, FrameLayout.LayoutParams(dp(56), dp(6), Gravity.CENTER))
        val back = TextView(this).apply {
            text = "‹"; setTextColor(Color.WHITE); textSize = 22f; gravity = Gravity.CENTER
            setOnClickListener { thread { try { svc?.key(vw.displayId, KeyEvent.KEYCODE_BACK) } catch (ignored: Throwable) {} } }
        }
        bar.addView(back, FrameLayout.LayoutParams(dp(36), dp(24), Gravity.START))
        root.addView(bar, FrameLayout.LayoutParams(-1, dp(24), Gravity.TOP))

        var downX = 0f; var downY = 0f; var sx0 = 0; var sy0 = 0; var moved = false
        bar.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; sx0 = vw.lp.x; sy0 = vw.lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - downX) > dp(6) || abs(e.rawY - downY) > dp(6)) moved = true
                    if (moved && !vw.full) {
                        vw.lp.x = (sx0 + (e.rawX - downX).toInt()).coerceIn(-vw.sw / 2, W - vw.sw / 2)
                        vw.lp.y = (sy0 + (e.rawY - downY).toInt()).coerceIn(0, H - dp(24))
                        try { wm.updateViewLayout(root, vw.lp) } catch (ignored: Throwable) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleFull(vw)
                    else if (!vw.full) {
                        if (e.rawX > W - dp(40)) closeVirtual(pkg) else { vw.sx = vw.lp.x; vw.sy = vw.lp.y }
                    }
                }
            }
            true
        }

        // touches on the app: map from the small view to the full-size virtual display
        tv.setOnTouchListener { v, e ->
            val id = vw.displayId
            if (id >= 0 && v.width > 0) {
                val act = when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { vw.downTime = SystemClock.uptimeMillis(); MotionEvent.ACTION_DOWN }
                    MotionEvent.ACTION_MOVE -> MotionEvent.ACTION_MOVE
                    MotionEvent.ACTION_UP -> MotionEvent.ACTION_UP
                    MotionEvent.ACTION_CANCEL -> MotionEvent.ACTION_CANCEL
                    else -> -1
                }
                if (act >= 0) try { svc?.inject(id, act, e.x / v.width * W, e.y / v.height * H, vw.downTime) } catch (ignored: Throwable) {}
            }
            true
        }

        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, sw: Int, sh: Int) {
                val surface = Surface(st); vw.surface = surface
                thread {
                    val s = svc
                    val id = try { s?.createDisplay(surface, W, H, dm.densityDpi) ?: -1 } catch (ignored: Throwable) { -1 }
                    if (id < 0) {
                        val er = try { s?.lastError() } catch (ignored: Throwable) { null }
                        ui.post { removeVirtual(pkg, false); toast("Zoom-out mode പറ്റിയില്ല (${er ?: "no service"}) → small window"); legacyOpen(pkg, slot) }
                    } else {
                        vw.displayId = id
                        try { s?.launch(id, comp) } catch (ignored: Throwable) {}
                    }
                }
            }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }

        val p = lp(w, h, Gravity.TOP or Gravity.START, x, y)
        vw.root = root; vw.lp = p
        vwins[pkg] = vw
        root.alpha = 0f; root.scaleX = 0.8f; root.scaleY = 0.8f
        root.pivotX = w / 2f; root.pivotY = h / 2f
        wm.addView(root, p)
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(300).setInterpolator(EASE_OUT).withLayer().start()
    }

    private fun toggleFull(vw: VWin) {
        val dm = resources.displayMetrics
        val fx = vw.lp.x; val fy = vw.lp.y; val fw = vw.lp.width; val fh = vw.lp.height
        val goFull = !vw.full
        vw.full = goFull
        val tx = if (goFull) 0 else vw.sx; val ty = if (goFull) 0 else vw.sy
        val tw = if (goFull) dm.widthPixels else vw.sw; val th = if (goFull) dm.heightPixels else vw.sh
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 280; interpolator = EASE_OUT
            addUpdateListener {
                val f = it.animatedValue as Float
                vw.lp.x = (fx + (tx - fx) * f).toInt(); vw.lp.y = (fy + (ty - fy) * f).toInt()
                vw.lp.width = (fw + (tw - fw) * f).toInt(); vw.lp.height = (fh + (th - fh) * f).toInt()
                try { wm.updateViewLayout(vw.root, vw.lp) } catch (ignored: Throwable) { cancel() }
            }
            start()
        }
    }

    private fun removeVirtual(pkg: String, animate: Boolean) {
        val vw = vwins.remove(pkg) ?: return
        slotOf.remove(pkg)
        vw.closing = true
        val done: () -> Unit = {
            try { wm.removeView(vw.root) } catch (ignored: Throwable) {}
            try { vw.surface?.release() } catch (ignored: Throwable) {}
        }
        if (animate) {
            vw.root.pivotX = vw.root.width / 2f; vw.root.pivotY = vw.root.height / 2f
            vw.root.animate().alpha(0f).scaleX(0.8f).scaleY(0.8f).setDuration(200).setInterpolator(EASE_IN).withLayer().withEndAction(done).start()
        } else done()
    }

    private fun closeVirtual(pkg: String) {
        val id = vwins[pkg]?.displayId ?: -1
        removeVirtual(pkg, true)
        thread {
            try { if (id >= 0) svc?.release(id) } catch (ignored: Throwable) {}
            Shell.close(pkg)
        }
    }

    private fun closeLegacy(pkg: String) {
        val w = wins.remove(pkg) ?: return
        slotOf.remove(pkg)
        try { wm.removeView(w.grip) } catch (ignored: Throwable) {}
        thread { Shell.close(pkg) }
    }

    private fun closeAll() {
        vwins.keys.toList().forEach { closeVirtual(it) }
        wins.keys.toList().forEach { closeLegacy(it) }
    }

    // =====================================================================
    //  Fallback: old freeform small windows
    // =====================================================================
    private fun legacySlotRect(slot: Int): IntArray {
        val dm = resources.displayMetrics; val m = dp(6); val top = dp(36); val bottom = dp(24)
        val cw = (dm.widthPixels - m * 3) / 2
        val ch = (dm.heightPixels - top - bottom - m * 4) / 3
        return intArrayOf(m + (slot % 2) * (cw + m), top + m + (slot / 2) * (ch + m), cw, ch)
    }

    private fun legacyOpen(pkg: String, slot: Int) {
        slotOf[pkg] = slot
        val (l, t, w, h) = legacySlotRect(slot)
        thread {
            val id = Shell.launchFreeform(pkg, l, t, l + w, t + h)
            ui.post {
                if (id > 0) addWindow(pkg, slot, id, l, t, w, h) else { slotOf.remove(pkg); toast("ഈ ആപ്പ് small window ആയി തുറക്കുന്നില്ല") }
            }
        }
    }

    /** Lavender grip on top of each freeform window: drag = move, drag into right edge = close, long-press = fullscreen / back to small. */
    private fun addWindow(pkg: String, slot: Int, id: Int, l: Int, t: Int, w: Int, h: Int) {
        val dm = resources.displayMetrics
        val grip = View(this).apply { background = GradientDrawable().apply { setColor(LAV); cornerRadius = dp(5).toFloat(); setStroke(dp(1), Color.WHITE) } }
        val win = Win(pkg, slot, id, l, t, w, h, grip)
        val p = lp(w / 2, dp(14), Gravity.TOP or Gravity.START, l + w / 4, t + dp(3))
        var downX = 0f; var downY = 0f; var sx = 0; var sy = 0; var moved = false; var longDone = false

        val longPress = Runnable {
            longDone = true
            if (!win.full) {
                win.full = true
                thread { Shell.resize(id, 0, 0, dm.widthPixels, dm.heightPixels) }
                p.x = (dm.widthPixels - p.width) / 2; p.y = dp(30)
            } else {
                win.full = false
                thread { Shell.resize(id, win.l, win.t, win.l + win.w, win.t + win.h) }
                p.x = win.l + win.w / 4; p.y = win.t + dp(3)
            }
            wm.updateViewLayout(grip, p)
        }

        grip.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; sx = p.x; sy = p.y; moved = false; longDone = false; v.postDelayed(longPress, 500) }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - downX) > dp(8) || abs(e.rawY - downY) > dp(8)) { moved = true; v.removeCallbacks(longPress) }
                    if (moved && !longDone && !win.full) { p.x = sx + (e.rawX - downX).toInt(); p.y = sy + (e.rawY - downY).toInt(); wm.updateViewLayout(v, p) }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.removeCallbacks(longPress)
                    if (moved && !longDone && !win.full) {
                        if (e.rawX > dm.widthPixels - dp(40)) {
                            closeLegacy(pkg)
                        } else {
                            win.l = p.x - win.w / 4; win.t = p.y - dp(3)
                            thread { Shell.resize(id, win.l, win.t, win.l + win.w, win.t + win.h) }
                        }
                    }
                }
            }
            true
        }
        wins[pkg] = win; wm.addView(grip, p)
    }

    override fun onDestroy() {
        try { unregisterReceiver(pkgRx) } catch (ignored: Throwable) {}
        handle?.let { try { wm.removeView(it) } catch (ignored: Throwable) {} }
        panel?.let { try { wm.removeView(it) } catch (ignored: Throwable) {} }
        wins.values.forEach { try { wm.removeView(it.grip) } catch (ignored: Throwable) {} }; wins.clear()
        vwins.values.forEach {
            try { wm.removeView(it.root) } catch (ignored: Throwable) {}
            it.surface?.release()
            val id = it.displayId
            try { if (id >= 0) svc?.release(id) } catch (ignored: Throwable) {}
        }
        vwins.clear(); slotOf.clear()
        try { Shizuku.unbindUserService(userArgs, conn, true) } catch (ignored: Throwable) {}
        super.onDestroy()
    }
}
